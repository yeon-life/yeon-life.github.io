---
name: yeon-thinkmap
description: 연 프로젝트의 공통 "생각·학습 지도" 스킬. 캔버스 기반 그래프 시각화로 화면 한 가운데에 노드와 연결을 표시한다. 광장(글의 연결망), 학생 학습 지도(영풀·수풀·과풀·국풀·책풀), 독서 지도, 연플래너 주간 지도 등 어디든 같은 엔진을 데이터만 바꿔서 가져다 쓴다. 백업·복원이 일급 기능. 학생이 자기 지도를 언제든 JSON으로 받아 보관할 수 있다. 반드시 이 스킬을 사용해야 하는 상황 - 마인드맵, 생각의 지도, 학습 지도, 개념 지도, 독서 지도, 그래프 시각화, 노드 연결, 마을 글 연결망, 영풀·수풀·과풀·국풀·책풀에 학습 진행 시각화를 넣을 때, "내 생각을 키워보세요" 콘셉트의 화면, 학생이 자기 학습 풍경을 보는 페이지.
---

# yeon-thinkmap — 연 생각·학습 지도 스킬

> **"내 생각을 키워보세요"**
>
> 학생이 자기 생각이 자라는 풍경을 보며 뿌듯해하는 — 점수도 등수도 아닌, 자라는 지도.

---

## 1. 이 스킬을 언제 부르는가

다음과 같은 화면이나 페이지를 만들 때 **반드시** 이 스킬을 가져다 쓴다.

- 광장(아골라·아곤란·시민저널)의 글 연결망 시각화
- 학생용 **내 학습 지도** (책풀·영풀·수풀·과풀·국풀)
- **내 독서 지도** — 읽은 책, 읽다 만 책, 메모 많은 책의 흔적
- 연플래너 **주간 활동 지도**
- 그 외 "노드-엣지 그래프"가 필요한 모든 자리

같은 엔진, 같은 인터랙션, 같은 백업 기능. **데이터와 카테고리만** 도메인에 맞게 바꿔서 쓴다.

---

## 2. 사용법 — 3줄이면 끝

```html
<link rel="stylesheet" href="engine/thinkmap.css">
<div id="map" style="height: 100vh;"></div>
<script src="engine/thinkmap.js"></script>
<script>
  YeonThinkMap.mount('#map', {
    nodes: [
      { id: 'n1', label: '분수의 덧셈', cat: '복습필요', mastery: 62 },
      { id: 'n2', label: '분수의 곱셈', cat: '완전학습', mastery: 88 },
    ],
    edges: [{ from: 'n1', to: 'n2', type: 'similar' }],
    options: { title: '내 수학 지도' }
  });
</script>
```

---

## 3. 핵심 API

### `YeonThinkMap.mount(selector, config)`

| 옵션 | 타입 | 기본값 | 설명 |
|---|---|---|---|
| `nodes` | Array | `[]` | 노드 배열 |
| `edges` | Array | `[]` | 엣지 배열 |
| `categories` | Object | 학습 5색 | 카테고리 색·라벨·툴팁 |
| `options.title` | string | `'생각의 지도'` | 좌상단 페이지 제목 |
| `options.tagline` | string | `'내 생각을 키워보세요'` | 검색 placeholder + 하단 모토 |
| `options.autoCategorize` | bool | `false` | `mastery + 시간`으로 `cat` 자동 분류 |
| `options.autoSize` | bool | `false` | 시도·메모·연결로 노드 크기 자동 |
| `options.showHeader` | bool | `true` | 상단 헤더 표시 |
| `options.showLegend` | bool | `true` | 좌하단 범례 |
| `options.showZoom` | bool | `true` | 우하단 줌 컨트롤 |
| `options.showBackup` | bool | `true` | 우상단 백업 버튼 |
| `onNodeClick` | fn | — | 노드 클릭 콜백 |

### 인스턴스 메서드

| 메서드 | 용도 |
|---|---|
| `map.update({nodes, edges})` | 데이터 교체 |
| `map.addNode(node)` | 노드 한 개 추가 |
| `map.removeNode(id)` | 노드 삭제 + 관련 엣지 자동 삭제 |
| `map.addEdge(edge)` | 엣지 추가 |
| `map.refreshStates()` | 망각곡선 적용 — `mastery`와 시간 흐름으로 `cat` 재분류 |
| **`map.export('json')`** | **JSON 백업 문자열** |
| **`map.export('md')`** | **Markdown 백업 문자열** |
| **`map.export('png')`** | **현재 화면 PNG dataURL** |
| **`map.import(json, {mode})`** | **JSON 복원** (`mode: 'replace' | 'merge'`) |
| `map.openDetail(node)` | 우측 상세 패널 열기 |
| `map.destroy()` | 정리 |

---

## 4. 데이터 형식

### 노드

```js
{
  id: 'math-frac-add-001',     // 필수 — 고유 ID
  label: '분수의 덧셈',          // 화면에 보이는 짧은 이름
  cat: '복습필요',               // 카테고리 키 — categories 객체의 키
  domain: '수풀',                // 옵션 — 도메인 구분
  subject: '분수와 소수',        // 옵션 — 단원

  // 학습 메타데이터 (옵션)
  mastery: 62,                  // 0~100 숙달도
  attempts: 8,                  // 시도 횟수
  correct: 5,                   // 정답 횟수
  notesLength: 240,             // 메모·하이라이트 글자 수
  totalSeconds: 720,            // 누적 학습 시간 (초)
  importance: 0.7,              // 0~1 단원 핵심성
  connections: 6,               // 자동 계산되어 들어옴 — 또는 미리 지정

  // 시간 흔적
  firstSeen: '2026-04-10T...',  // ISO
  lastSeen: '2026-05-14T...',
  lastReviewedAt: '2026-05-12T...',

  // 시각 (옵션 — autoSize 켜면 자동)
  size: 1.2,                    // 0.5~2.0
  x: 0.42, y: 0.55,             // 0~1 위치 비율 (없으면 랜덤)

  // 내용
  body: '문제 본문 또는 개념 설명',
  source: '디딤돌 초등 5-1 p.42',
  notes: '학생 자유 메모',
  url: '/문제/123',             // 클릭 시 이동할 URL
  by: '임선생',                  // 작성자(광장 글일 때)
  time: '5월 14일',              // 표시용 짧은 시간
}
```

### 엣지

```js
{ from: 'n1', to: 'n2', type: 'similar', strength: 0.8 }

// 또는 짧게:
['n1', 'n2']

// 또는 광장식:
{ a: 'n1', b: 'n2' }
```

엣지 타입 권장값: `'similar' | 'prerequisite' | 'application' | 'same-source' | 'mistake-link' | 'connection'`

### 카테고리

```js
{
  '완전학습': { color: '#4a9060', label: '완전 학습', tooltip: '여긴 든든하구나' },
  '복습필요': { color: '#c4923e', label: '복습 필요', tooltip: '이거 잊고 있었네' },
  '잘모름':   { color: '#c05040', label: '잘 모름',   tooltip: '여기 손볼 자리가 있구나' },
  '새것':     { color: '#3aa0a8', label: '새것',      tooltip: '오늘 새로 만났구나' },
  '응용':     { color: '#6858c0', label: '응용·연결', tooltip: '다른 것과 이어졌구나' },
}
```

도메인마다 자유롭게 정의. 광장이라면 `화두/아골라/아곤란/칼럼/연마을`, 독서라면 `완독/읽는중/멈춤/다시읽기` 등.

---

## 5. 백업·복원 — 학생 자료 소유권

연라이프 정신: **"여기서 쓴 모든 것은 당신의 자산입니다."**

이 스킬을 부르면 우상단에 **⤓ 백업 버튼**이 자동으로 생긴다. 학생은 클릭만으로:

- 📁 **JSON으로 내려받기** — 완전 백업. 미래의 다른 도구에서도 읽을 수 있음
- 📝 **Markdown으로 내려받기** — 카테고리별로 정리된 일지 형태
- 🖼 **PNG로 내려받기** — 지금 보이는 화면 그대로 그림
- 📂 **JSON 가져오기** — 백업 파일에서 복원

**파일명**은 자동으로 `{title}-{YYYY-MM-DD}.{ext}` 형식. 예: `내수학지도-2026-05-15.json`

### JSON 백업 구조

```json
{
  "_meta": {
    "yeon_thinkmap_version": "1.0",
    "exported_at": "2026-05-15T22:30:00.000Z",
    "title": "내 수학 지도",
    "tagline": "내 생각을 키워보세요",
    "node_count": 247,
    "edge_count": 412
  },
  "categories": { ... },
  "nodes": [ ... ],
  "edges": [ ... ],
  "settings": { "view": { "scale": 1, "ox": 0, "oy": 0 } }
}
```

학교나 플랫폼 서비스가 중단되어도, 학생은 자기 JSON만 있으면 다른 도구로 옮길 수 있다.

---

## 6. 학습 상태 자동 분류 (mastery → cat)

`options.autoCategorize: true` 로 켜면 `mastery + 마지막 학습일 + 시도 횟수`로 카테고리가 자동 결정된다.

| 조건 | → 카테고리 |
|---|---|
| `attempts ≤ 1` 그리고 학습한 지 3일 이내 | 🔵 **새것** |
| `mastery < 40` 그리고 2회 이상 시도 | 🔴 **잘모름** |
| `mastery ≥ 80` 그리고 학습한 지 14일 이내 | 🟢 **완전학습** |
| 연결 5개 이상 그리고 `mastery ≥ 60` | 🟣 **응용·연결** |
| 그 외 | 🟡 **복습필요** |

망각곡선이 적용되어, 시간이 지나면 🟢이 천천히 🟡 → 🔴 로 흐려진다. 학생이 다시 만나면 색이 살아난다.

```js
// 매일 한 번씩 호출하면 망각곡선이 반영됨
map.refreshStates();
```

---

## 7. 다섯 가지 도메인 적용 예

### 광장 (공개)

```js
categories: {
  '화두':   { color: '#3aa0a8', label: '화두' },
  '아골라': { color: '#c4923e', label: '아골라' },
  '아곤란': { color: '#c05040', label: '아곤란' },
  '칼럼':   { color: '#6858c0', label: '칼럼' },
  '연마을': { color: '#4a9060', label: '연마을' },
}
options: { title: '광장 생각의 지도', autoCategorize: false }
```

### 수풀·영풀·과풀·국풀 (학생 비공개)

```js
categories: 학습5색
options: {
  title: '내 수학 지도',
  tagline: '내 생각을 키워보세요',
  autoCategorize: true,
  autoSize: true,
}
```

### 책풀 (독서 지도)

```js
categories: {
  '완독':     { color: '#4a9060', label: '완독한 책' },
  '읽는중':   { color: '#3aa0a8', label: '지금 읽는 중' },
  '멈춤':     { color: '#c4923e', label: '읽다 만 책' },
  '다시':     { color: '#6858c0', label: '다시 읽고 싶은' },
  '계획':     { color: '#c05040', label: '읽을 책' },
}
```

노드 크기 = 메모·밑줄·생각의 양 → 깊이 읽은 책일수록 큰 흔적

### 연플래너 주간 지도

매주 새로 그려지는 한 주의 활동. 색 = 활동 종류(공부/운동/사람 만남/책 읽기/혼자 시간)

---

## 8. 결정된 정책 (구현 시 따를 것)

- ✅ 학생 노드 직접 추가 **가능**
- ✅ 노드 위치 끌어 옮기기 **가능** (저장됨)
- ✅ 학습 시간 추적 — 학생이 켜고 끌 수 있어야 함
- ✅ 초기 노드 위치 — 카테고리 클러스터 + 같은 단원 인접 배치
- ✅ 부모·교사 접근 — **기본 비공개**. 학생이 명시적으로 공유 허락한 경우만
- ✅ AI 엣지 생성 — 새 노드 추가 시 즉시, 전체 재계산 주 1회 야간

---

## 9. 파일 구조

```
yeon-thinkmap/
├─ SKILL.md                  # 이 문서
├─ engine/
│  ├─ thinkmap.js            # 메인 엔진
│  └─ thinkmap.css           # 스타일 (다크·라이트)
├─ examples/
│  ├─ 광장.json
│  ├─ 수풀_학습지도.json
│  ├─ 영풀.json
│  ├─ 책풀_독서지도.json
│  └─ 연플래너_주간.json
└─ template.html             # 최소 임베드 예제
```

---

## 10. 절대 하지 말 것

- ❌ **다른 학생과 비교하는 화면 만들지 말 것.** 노드 크기·색은 "이 학생 본인의 학습 풍경"이지 "다른 학생 대비 점수"가 아니다.
- ❌ **랭킹·등수 UI 만들지 말 것.** 연라이프 정서와 정면 충돌한다.
- ❌ **백업 기능 빼지 말 것.** 학생 자료 소유권의 핵심.
- ❌ **클라우드 종속 만들지 말 것.** JSON 백업 하나면 어디든 옮길 수 있어야 한다.
