/* ════════════════════════════════════════════════════════════════
   YeonAnalytics — 연 학습 분석 대시보드
   ────────────────────────────────────────────────────────────────
   yeon-thinkmap의 NODES / EDGES / categories 데이터를
   8가지 시각화로 다른 각도에서 봅니다.

   사용법:
     YeonAnalytics.mount('#dashboard', {
       nodes: [...], edges: [...], categories: {...},
       options: { title: '내 학습 분석', tagline: '내 생각을 키워보세요' }
     });

   외부 의존성: Chart.js (CDN으로 미리 로드)
   ════════════════════════════════════════════════════════════════ */

(function(global) {
  'use strict';

  const TEXT_COLOR = '#f0ede2';
  const MUTED = 'rgba(240,237,226,.55)';
  const GRID = 'rgba(255,255,255,.06)';

  // Chart.js 전역 기본값 — 한 번만 설정
  function setChartDefaults() {
    if (!global.Chart) return;
    Chart.defaults.color = MUTED;
    Chart.defaults.borderColor = GRID;
    Chart.defaults.font.family = '"Pretendard","Apple SD Gothic Neo",sans-serif';
    Chart.defaults.font.size = 11;
    Chart.defaults.plugins.legend.labels.boxWidth = 10;
    Chart.defaults.plugins.legend.labels.padding = 8;
  }

  class YeonAnalytics {
    static mount(selector, config) {
      const el = typeof selector === 'string' ? document.querySelector(selector) : selector;
      if (!el) throw new Error('[YeonAnalytics] container not found');
      return new YeonAnalytics(el, config || {});
    }

    constructor(container, config) {
      this.container = container;
      this.nodes = config.nodes || [];
      this.edges = config.edges || [];
      this.categories = config.categories || {};
      this.options = Object.assign({
        title: '내 학습 분석',
        tagline: '내 생각을 키워보세요',
      }, config.options || {});
      this._charts = [];

      setChartDefaults();
      this._buildDOM();
      this._render();
    }

    _buildDOM() {
      this.container.classList.add('yta-root');
      this.container.innerHTML = `
        <div class="yta-head">
          <div class="yta-title">${esc(this.options.title)}</div>
          <div class="yta-tagline">${esc(this.options.tagline)}</div>
        </div>
        <div class="yta-grid">

          <div class="yta-card yta-col-4">
            <div class="yta-card-head">
              <div class="yta-card-title">학습 상태 분포</div>
              <span class="yta-card-sub">전체 ${this.nodes.length}개</span>
            </div>
            <div class="yta-canvas-wrap yta-canvas-wrap--md">
              <canvas data-chart="state-donut"
                role="img"
                aria-label="학습 상태별 노드 분포 도넛 차트"></canvas>
            </div>
          </div>

          <div class="yta-card yta-col-5">
            <div class="yta-card-head">
              <div class="yta-card-title">단원별 분포</div>
              <span class="yta-card-sub">사각형 면적 = 노드 수</span>
            </div>
            <div class="yta-treemap" data-treemap></div>
          </div>

          <div class="yta-card yta-col-3">
            <div class="yta-card-head">
              <div class="yta-card-title">카테고리별 평균 숙달도</div>
            </div>
            <div class="yta-canvas-wrap yta-canvas-wrap--md">
              <canvas data-chart="cat-mastery"
                role="img"
                aria-label="카테고리별 평균 숙달도 막대 차트"></canvas>
            </div>
          </div>

          <div class="yta-card yta-col-7">
            <div class="yta-card-head">
              <div class="yta-card-title">곧 흐려질 자리 (망각 위험순)</div>
              <span class="yta-card-sub">마지막 학습 후 시간 ↑</span>
            </div>
            <div class="yta-canvas-wrap yta-canvas-wrap--md">
              <canvas data-chart="forgetting"
                role="img"
                aria-label="망각 위험 상위 노드 막대 차트"></canvas>
            </div>
          </div>

          <div class="yta-card yta-col-5">
            <div class="yta-card-head">
              <div class="yta-card-title">시험 대비 (단원별 준비도)</div>
              <span class="yta-card-sub">각 축 = 단원 평균 숙달도</span>
            </div>
            <div class="yta-canvas-wrap yta-canvas-wrap--md">
              <canvas data-chart="exam-radar"
                role="img"
                aria-label="시험 대비 단원별 준비도 레이더 차트"></canvas>
            </div>
          </div>

          <div class="yta-card yta-col-8">
            <div class="yta-card-head">
              <div class="yta-card-title">
                학습 변화 (지난 30일)
                <span class="yta-badge-example">예시</span>
              </div>
              <span class="yta-card-sub">평균 숙달도 추이</span>
            </div>
            <div class="yta-canvas-wrap yta-canvas-wrap--md">
              <canvas data-chart="trend-line"
                role="img"
                aria-label="지난 30일 평균 숙달도 변화 라인 차트"></canvas>
            </div>
          </div>

          <div class="yta-card yta-col-4">
            <div class="yta-card-head">
              <div class="yta-card-title">
                풀이 스타일 자화상
                <span class="yta-badge-example">예시</span>
              </div>
            </div>
            <div class="yta-canvas-wrap yta-canvas-wrap--md">
              <canvas data-chart="style-donut"
                role="img"
                aria-label="선호 풀이 스타일 분포 도넛 차트"></canvas>
            </div>
          </div>

          <div class="yta-card yta-col-7">
            <div class="yta-card-head">
              <div class="yta-card-title">
                풀이 요청 빈도
                <span class="yta-badge-example">예시</span>
              </div>
              <span class="yta-card-sub">자기 방식이 잡히지 않은 자리</span>
            </div>
            <div class="yta-heatmap" data-heatmap></div>
          </div>

          <div class="yta-card yta-col-5">
            <div class="yta-card-head">
              <div class="yta-card-title">
                일별 학습 흔적
                <span class="yta-badge-example">예시</span>
              </div>
              <span class="yta-card-sub">지난 60일</span>
            </div>
            <div class="yta-calendar" data-calendar></div>
          </div>

        </div>
      `;
    }

    _render() {
      this._renderStateDonut();
      this._renderCategoryMastery();
      this._renderForgetting();
      this._renderExamRadar();
      this._renderSubjectTreemap();
      this._renderTrendLine();
      this._renderStyleDonut();
      this._renderRequestHeatmap();
      this._renderCalendar();
    }

    /* ── 1. 학습 상태 도넛 ─────────────────────────────────── */
    _renderStateDonut() {
      const cats = this.categories;
      const counts = {};
      const colors = [];
      const labels = [];
      const data = [];
      for (const [key, info] of Object.entries(cats)) {
        const c = this.nodes.filter(n => n.cat === key).length;
        if (!c) continue;
        labels.push(info.label || key);
        data.push(c);
        colors.push(info.color);
      }
      const canvas = this.container.querySelector('[data-chart="state-donut"]');
      if (!canvas || !global.Chart) return;
      this._charts.push(new Chart(canvas, {
        type: 'doughnut',
        data: { labels, datasets: [{ data, backgroundColor: colors, borderColor: 'rgba(0,0,0,0)', borderWidth: 2 }] },
        options: {
          responsive: true, maintainAspectRatio: false, cutout: '62%',
          plugins: {
            legend: { position: 'right', labels: { color: TEXT_COLOR, boxWidth: 10, padding: 8, font: { size: 11 } } },
            tooltip: { callbacks: { label: ctx => ctx.label + ' ' + ctx.parsed + '개' } },
          },
        },
      }));
    }

    /* ── 2. 카테고리별 평균 숙달도 막대 ────────────────────── */
    _renderCategoryMastery() {
      const cats = this.categories;
      const labels = [];
      const data = [];
      const colors = [];
      for (const [key, info] of Object.entries(cats)) {
        const ns = this.nodes.filter(n => n.cat === key && n.mastery !== undefined);
        if (!ns.length) continue;
        const avg = ns.reduce((s, n) => s + n.mastery, 0) / ns.length;
        labels.push(info.label || key);
        data.push(Math.round(avg));
        colors.push(info.color);
      }
      const canvas = this.container.querySelector('[data-chart="cat-mastery"]');
      if (!canvas || !global.Chart) return;
      this._charts.push(new Chart(canvas, {
        type: 'bar',
        data: { labels, datasets: [{ data, backgroundColor: colors, borderRadius: 4, barPercentage: 0.7 }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          indexAxis: 'y',
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: { label: ctx => '평균 ' + ctx.parsed.x } },
          },
          scales: {
            x: { min: 0, max: 100, grid: { color: GRID }, ticks: { color: MUTED } },
            y: { grid: { display: false }, ticks: { color: TEXT_COLOR, font: { size: 11 } } },
          },
        },
      }));
    }

    /* ── 3. 망각 위험 막대 ─────────────────────────────────── */
    _renderForgetting() {
      const today = new Date();
      const ns = this.nodes
        .filter(n => n.lastSeen)
        .map(n => {
          const days = Math.max(0, (today - new Date(n.lastSeen)) / (1000 * 60 * 60 * 24));
          const baseMastery = n.mastery ?? 50;
          // 망각 점수 = 마지막 학습 이후 일수 × (100 - mastery) 정규화
          const risk = Math.min(100, Math.round((days * (110 - baseMastery)) / 10));
          return { node: n, days: Math.round(days), risk };
        })
        .sort((a, b) => b.risk - a.risk)
        .slice(0, 8);

      const cats = this.categories;
      const labels = ns.map(x => x.node.label || '');
      const data = ns.map(x => x.risk);
      const colors = ns.map(x => (cats[x.node.cat] || {}).color || '#888');
      const daysArr = ns.map(x => x.days);

      const canvas = this.container.querySelector('[data-chart="forgetting"]');
      if (!canvas || !global.Chart) return;
      this._charts.push(new Chart(canvas, {
        type: 'bar',
        data: { labels, datasets: [{ data, backgroundColor: colors, borderRadius: 4, barPercentage: 0.75 }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          indexAxis: 'y',
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: ctx => '망각 위험 ' + ctx.parsed.x + ' · 마지막 학습 ' + daysArr[ctx.dataIndex] + '일 전',
              },
            },
          },
          scales: {
            x: { min: 0, max: 100, grid: { color: GRID }, ticks: { color: MUTED } },
            y: { grid: { display: false }, ticks: { color: TEXT_COLOR, font: { size: 11 } } },
          },
        },
      }));
    }

    /* ── 4. 시험 대비 레이더 ───────────────────────────────── */
    _renderExamRadar() {
      const bySubject = {};
      for (const n of this.nodes) {
        const s = n.subject || n.domain || '기타';
        if (!bySubject[s]) bySubject[s] = [];
        if (n.mastery !== undefined) bySubject[s].push(n.mastery);
      }
      const subjects = Object.keys(bySubject).slice(0, 8);
      const labels = subjects;
      const data = subjects.map(s => {
        const arr = bySubject[s];
        if (!arr.length) return 0;
        return Math.round(arr.reduce((a, b) => a + b, 0) / arr.length);
      });

      const canvas = this.container.querySelector('[data-chart="exam-radar"]');
      if (!canvas || !global.Chart) return;
      this._charts.push(new Chart(canvas, {
        type: 'radar',
        data: {
          labels,
          datasets: [{
            label: '평균 숙달도',
            data,
            backgroundColor: 'rgba(58,160,168,.18)',
            borderColor: '#3aa0a8',
            borderWidth: 2,
            pointBackgroundColor: '#3aa0a8',
            pointRadius: 3,
          }],
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            r: {
              min: 0, max: 100,
              ticks: { color: MUTED, backdropColor: 'transparent', font: { size: 9 }, stepSize: 25 },
              grid: { color: GRID },
              angleLines: { color: GRID },
              pointLabels: { color: TEXT_COLOR, font: { size: 11 } },
            },
          },
        },
      }));
    }

    /* ── 5. 단원별 트리맵 (CSS) ────────────────────────────── */
    _renderSubjectTreemap() {
      const wrap = this.container.querySelector('[data-treemap]');
      if (!wrap) return;
      const cats = this.categories;
      const bySubject = {};
      for (const n of this.nodes) {
        const s = n.subject || n.domain || '기타';
        if (!bySubject[s]) bySubject[s] = [];
        bySubject[s].push(n);
      }
      const entries = Object.entries(bySubject)
        .map(([name, ns]) => {
          const avg = ns.filter(n => n.mastery !== undefined)
            .reduce((s, n, _, arr) => s + n.mastery / arr.length, 0);
          // 가장 흔한 카테고리 색
          const counts = {};
          for (const n of ns) counts[n.cat] = (counts[n.cat] || 0) + 1;
          let topCat = ns[0].cat, max = 0;
          for (const k in counts) if (counts[k] > max) { max = counts[k]; topCat = k; }
          return { name, count: ns.length, avg: Math.round(avg), color: (cats[topCat] || {}).color || '#888' };
        })
        .sort((a, b) => b.count - a.count);

      const total = entries.reduce((s, e) => s + e.count, 0);
      wrap.innerHTML = entries.map(e => {
        const flex = Math.max(0.4, e.count / Math.max(1, total) * 10);
        return `
          <div class="yta-treemap-cell"
               style="flex: ${flex.toFixed(2)} 1 80px; background: ${e.color}33; border: 1px solid ${e.color}66; color: ${e.color};"
               title="${esc(e.name)} · ${e.count}개 · 평균 ${e.avg}">
            <div class="yta-treemap-cell-label" style="color: var(--yta-ink-primary);">${esc(e.name)}</div>
            <div class="yta-treemap-cell-num" style="color: ${e.color};">${e.count}</div>
            <div class="yta-treemap-cell-bar" style="width: ${e.avg}%; background: ${e.color};"></div>
          </div>`;
      }).join('');
    }

    /* ── 6. 학습 변화 라인 (예시 데이터) ──────────────────── */
    _renderTrendLine() {
      // 현재 평균 mastery 를 기준으로 30일 전부터 우상향하는 곡선 생성
      const ns = this.nodes.filter(n => n.mastery !== undefined);
      const currentAvg = ns.length ? ns.reduce((s, n) => s + n.mastery, 0) / ns.length : 60;
      const days = 30;
      const labels = [];
      const data = [];
      const now = new Date();
      for (let i = days - 1; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        labels.push((d.getMonth() + 1) + '/' + d.getDate());
        const progress = (days - 1 - i) / (days - 1);
        const base = currentAvg - 25 + progress * 25;
        const wobble = Math.sin(i * 0.7) * 4 + Math.cos(i * 0.4) * 3;
        data.push(Math.max(0, Math.min(100, Math.round(base + wobble))));
      }

      const canvas = this.container.querySelector('[data-chart="trend-line"]');
      if (!canvas || !global.Chart) return;
      this._charts.push(new Chart(canvas, {
        type: 'line',
        data: {
          labels,
          datasets: [{
            label: '평균 숙달도',
            data,
            borderColor: '#3aa0a8',
            backgroundColor: 'rgba(58,160,168,.12)',
            fill: true,
            tension: 0.32,
            borderWidth: 2,
            pointRadius: 0,
            pointHoverRadius: 5,
            pointBackgroundColor: '#3aa0a8',
          }],
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { grid: { color: GRID }, ticks: { color: MUTED, maxRotation: 0, autoSkipPadding: 16 } },
            y: { min: 0, max: 100, grid: { color: GRID }, ticks: { color: MUTED, stepSize: 25 } },
          },
        },
      }));
    }

    /* ── 7. 풀이 스타일 자화상 도넛 (예시) ────────────────── */
    _renderStyleDonut() {
      // 예시 분포 — 실제 운영에선 preferredApproach 누적 집계
      const labels = ['그림 풀이', '수식 풀이', '비교 풀이', '말로 풀이'];
      const data = [42, 28, 18, 12];
      const colors = ['#3aa0a8', '#c4923e', '#6858c0', '#4a9060'];

      const canvas = this.container.querySelector('[data-chart="style-donut"]');
      if (!canvas || !global.Chart) return;
      this._charts.push(new Chart(canvas, {
        type: 'doughnut',
        data: { labels, datasets: [{ data, backgroundColor: colors, borderColor: 'rgba(0,0,0,0)', borderWidth: 2 }] },
        options: {
          responsive: true, maintainAspectRatio: false, cutout: '62%',
          plugins: {
            legend: { position: 'right', labels: { color: TEXT_COLOR, boxWidth: 10, padding: 8, font: { size: 11 } } },
            tooltip: { callbacks: { label: ctx => ctx.label + ' ' + ctx.parsed + '%' } },
          },
        },
      }));
    }

    /* ── 8. 풀이 요청 빈도 히트맵 (예시) ──────────────────── */
    _renderRequestHeatmap() {
      const wrap = this.container.querySelector('[data-heatmap]');
      if (!wrap) return;
      // 상위 8개 노드 × 7주
      const ns = this.nodes.slice(0, 8);
      const weeks = 7;
      wrap.style.gridTemplateRows = `repeat(${ns.length}, 1fr)`;
      wrap.innerHTML = ns.map((n, i) => {
        // 예시 빈도: 노드 이름 해시 기반 의사 무작위
        const cells = [];
        for (let w = 0; w < weeks; w++) {
          const seed = (n.label || '').charCodeAt(0) * (w + 3) + i * 7;
          const v = Math.abs(Math.sin(seed)) * (i % 3 === 0 ? 1 : 0.5);
          const alpha = 0.08 + v * 0.7;
          cells.push(`<div class="yta-heatmap-cell" style="background: rgba(58,160,168,${alpha.toFixed(2)});" title="${esc(n.label)} · ${w + 1}주 전: ${Math.round(v * 5)}회"></div>`);
        }
        return `
          <div class="yta-heatmap-row">
            <div class="yta-heatmap-label">${esc((n.label || '').slice(0, 10))}</div>
            <div class="yta-heatmap-cells">${cells.join('')}</div>
          </div>`;
      }).join('');
    }

    /* ── 9. 일별 학습 캘린더 (예시) ──────────────────────── */
    _renderCalendar() {
      const wrap = this.container.querySelector('[data-calendar]');
      if (!wrap) return;
      const days = 70;
      const today = new Date();
      const cells = [];
      for (let i = days - 1; i >= 0; i--) {
        const d = new Date(today);
        d.setDate(d.getDate() - i);
        // 예시 활동: 의사 무작위, 최근일수록 진해짐
        const dayOfWeek = d.getDay();
        const recencyFactor = (days - i) / days;
        const seed = i * 13 + dayOfWeek * 5;
        const baseV = Math.abs(Math.sin(seed)) * recencyFactor;
        const intensity = dayOfWeek === 0 ? baseV * 0.3 : baseV; // 일요일은 낮음
        const alpha = intensity > 0.05 ? 0.15 + intensity * 0.7 : 0;
        const color = alpha > 0 ? `rgba(58,160,168,${alpha.toFixed(2)})` : 'rgba(255,255,255,.04)';
        cells.push(`<div class="yta-cal-cell" style="background:${color};" title="${d.getMonth() + 1}/${d.getDate()} · ${Math.round(intensity * 10)}개 학습"></div>`);
      }
      // 7 행 (월~일) × N 열
      wrap.innerHTML = `
        <div class="yta-cal-rows">${cells.join('')}</div>
        <div class="yta-cal-scale">
          <span>적음</span>
          <div class="yta-cal-scale-row">
            <div class="yta-cal-cell" style="background:rgba(255,255,255,.04);"></div>
            <div class="yta-cal-cell" style="background:rgba(58,160,168,.25);"></div>
            <div class="yta-cal-cell" style="background:rgba(58,160,168,.5);"></div>
            <div class="yta-cal-cell" style="background:rgba(58,160,168,.75);"></div>
            <div class="yta-cal-cell" style="background:rgba(58,160,168,1);"></div>
          </div>
          <span>많음</span>
        </div>
      `;
    }

    destroy() {
      this._charts.forEach(c => c.destroy && c.destroy());
      this._charts = [];
      this.container.innerHTML = '';
      this.container.classList.remove('yta-root');
    }
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  global.YeonAnalytics = YeonAnalytics;
})(window);
